from utils.validator import validate_id, validate_password, validate_email

def test_valid_clinician_id(): assert validate_id("12340000", "clinician")[0] is True
def test_invalid_clinician_id(): assert validate_id("12345678", "clinician")[0] is False
def test_valid_patient_id(): assert validate_id("12342024", "patient")[0] is True
def test_invalid_patient_id(): assert validate_id("12342030", "patient")[0] is False
def test_invalid_id_length(): assert validate_id("1234", "patient")[0] is False
def test_valid_password(): assert validate_password("Clinic@123")[0] is True
def test_short_password(): assert validate_password("Cli@12")[0] is False
def test_password_without_uppercase(): assert validate_password("clinic@123")[0] is False
def test_password_without_lowercase(): assert validate_password("CLINIC@123")[0] is False
def test_password_without_number(): assert validate_password("Clinic@abc")[0] is False
def test_password_without_special_character(): assert validate_password("Clinic123")[0] is False
def test_valid_email(): assert validate_email("user@example.com")[0] is True
def test_invalid_email(): assert validate_email("invalidemail")[0] is False
