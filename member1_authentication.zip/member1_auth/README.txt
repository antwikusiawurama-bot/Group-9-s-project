CLINICCARE-LITE - MEMBER 1 AUTHENTICATION

Install:
pip install flask bcrypt pytest

Run:
python app.py

Open:
http://127.0.0.1:5000/register

Test:
pytest tests/test_auth.py

Valid patient ID example: 12342024
Valid clinician ID example: 12340000
Valid password example: Clinic@123

The password is stored as a bcrypt hash.

The patient and clinician dashboard routes in this independent version are simple test pages. During final integration, keep the decorators and merge the authentication routes into the team's existing app.py. Do not duplicate existing dashboard routes.
