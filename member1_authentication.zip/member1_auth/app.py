import json
import os
import bcrypt
from flask import Flask, render_template, request, redirect, url_for, session, flash
from models.user import User
from utils.validator import validate_id, validate_password, validate_email
from utils.decorators import login_required, role_required

app = Flask(__name__)
app.secret_key = "change_this_to_a_secure_secret_key"
USERS_FILE = os.path.join("data", "users.json")

def load_users():
    if not os.path.exists(USERS_FILE):
        return []
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, FileNotFoundError):
        return []

def save_users(users):
    os.makedirs(os.path.dirname(USERS_FILE), exist_ok=True)
    with open(USERS_FILE, "w", encoding="utf-8") as file:
        json.dump(users, file, indent=4)

@app.route("/")
def home():
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        user_id = request.form.get("user_id", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "").strip().lower()
        if not name:
            flash("Full name is required.", "error"); return redirect(url_for("register"))
        valid, message = validate_id(user_id, role)
        if not valid:
            flash(message, "error"); return redirect(url_for("register"))
        valid, message = validate_email(email)
        if not valid:
            flash(message, "error"); return redirect(url_for("register"))
        valid, message = validate_password(password)
        if not valid:
            flash(message, "error"); return redirect(url_for("register"))
        users = load_users()
        for user in users:
            if user["user_id"] == user_id:
                flash("A user with this ID already exists.", "error"); return redirect(url_for("register"))
            if user["email"].lower() == email:
                flash("An account with this email already exists.", "error"); return redirect(url_for("register"))
        hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        users.append(User(user_id, name, email, hashed_password, role).to_dict())
        save_users(users)
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user_id = request.form.get("user_id", "").strip()
        password = request.form.get("password", "")
        user = next((u for u in load_users() if u["user_id"] == user_id), None)
        if user is None:
            flash("Invalid user ID or password.", "error"); return redirect(url_for("login"))
        try:
            password_matches = bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8"))
        except (ValueError, AttributeError):
            password_matches = False
        if not password_matches:
            flash("Invalid user ID or password.", "error"); return redirect(url_for("login"))
        if user.get("role") not in ["patient", "clinician"]:
            flash("Invalid user role.", "error"); return redirect(url_for("login"))
        session.clear()
        session["user_id"] = user["user_id"]
        session["role"] = user["role"]
        flash("Login successful.", "success")
        if user["role"] == "patient":
            return redirect(url_for("patient_dashboard"))
        return redirect(url_for("clinician_dashboard"))
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    session.clear(); flash("You have been logged out successfully.", "success"); return redirect(url_for("login"))

@app.route("/patient/dashboard")
@role_required("patient")
def patient_dashboard():
    return "<h1>Patient Dashboard</h1><p>You are logged in as a patient.</p><a href='/logout'>Logout</a>"

@app.route("/clinician/dashboard")
@role_required("clinician")
def clinician_dashboard():
    return "<h1>Clinician Dashboard</h1><p>You are logged in as a clinician.</p><a href='/logout'>Logout</a>"

if __name__ == "__main__":
    app.run(debug=True)
