import re

def validate_id(user_id, role):
    user_id = str(user_id)
    if not user_id.isdigit() or len(user_id) != 8:
        return False, "User ID must contain exactly 8 digits."
    if role == "clinician":
        if not user_id.endswith("0000"):
            return False, "Clinician ID must end in 0000."
    elif role == "patient":
        year = int(user_id[-4:])
        if year < 2022 or year > 2028:
            return False, "Patient ID must end with a year between 2022 and 2028."
    else:
        return False, "Invalid role selected."
    return True, "Valid user ID."

def validate_password(password):
    if len(password) < 8:
        return False, "Password must contain at least 8 characters."
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter."
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter."
    if not re.search(r"\d", password):
        return False, "Password must contain at least one number."
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, "Password must contain at least one special character."
    return True, "Valid password."

def validate_email(email):
    if re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", email):
        return True, "Valid email."
    return False, "Please enter a valid email address."
