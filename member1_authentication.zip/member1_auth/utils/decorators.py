from functools import wraps
from flask import session, redirect, url_for, flash

def login_required(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to access this page.", "error")
            return redirect(url_for("login"))
        return function(*args, **kwargs)
    return wrapper

def role_required(required_role):
    def decorator(function):
        @wraps(function)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in first.", "error")
                return redirect(url_for("login"))
            if session.get("role") != required_role:
                flash("You do not have permission to access this page.", "error")
                if session.get("role") == "patient":
                    return redirect(url_for("patient_dashboard"))
                if session.get("role") == "clinician":
                    return redirect(url_for("clinician_dashboard"))
                return redirect(url_for("login"))
            return function(*args, **kwargs)
        return wrapper
    return decorator
