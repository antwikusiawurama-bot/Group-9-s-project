import tkinter as tk
from tkinter import ttk, messagebox
import database


class GridCareLiteApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GridCare-Lite")
        self.root.geometry("900x600")
        database.setup_database()
        self.login_screen()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def login_screen(self):
        self.clear()
        ttk.Label(self.root, text="GRIDCARE-LITE",
                  font=("Arial", 24, "bold")).pack(pady=30)

        ttk.Label(self.root, text="Username").pack()
        self.username = ttk.Entry(self.root, width=30)
        self.username.pack(pady=5)

        ttk.Label(self.root, text="Password").pack()
        self.password = ttk.Entry(self.root, show="*", width=30)
        self.password.pack(pady=5)

        ttk.Button(self.root, text="Login",
                   command=self.login).pack(pady=20)

        ttk.Label(
            self.root,
            text="Demo: admin/1234  engineer/5678  technician/1711  customer_service/1911"
        ).pack(pady=10)

    def login(self):
        username = self.username.get().strip()
        password = self.password.get()
        role = database.check_login(username, password)

        if role:
            self.username_value = username
            self.show_dashboard(role)
        else:
            messagebox.showerror("Login Error", "Wrong username or password.")

    def show_dashboard(self, role):
        self.clear()

        ttk.Label(self.root, text="GRIDCARE-LITE DASHBOARD",
                  font=("Arial", 20, "bold")).pack(pady=15)
        ttk.Label(
            self.root,
            text=f"Logged in as: {self.username_value} ({role})"
        ).pack(pady=5)

        if role == "engineer":
            self.engineer_page()
        elif role == "admin":
            self.admin_page()
        elif role == "technician":
            self.technician_page()
        elif role == "customer_service":
            self.customer_page()

        ttk.Button(self.root, text="Logout",
                   command=self.login_screen).pack(side="bottom", pady=15)

    def outage_table(self, parent, rows):
        columns = ("ID", "Substation", "Region", "Description",
                   "Severity", "Status", "Reported")
        tree = ttk.Treeview(parent, columns=columns,
                            show="headings", height=10)
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=105)
        tree.column("Description", width=170)

        for row in rows:
            tree.insert("", "end", values=row)

        tree.pack(fill="both", expand=True, padx=10, pady=10)
        return tree

    def engineer_page(self):
        frame = ttk.LabelFrame(self.root, text="Report New Outage")
        frame.pack(fill="x", padx=20, pady=10)

        ttk.Label(frame, text="Substation").grid(row=0, column=0, padx=5, pady=5)
        subs = database.get_substations()
        self.substation_map = {
            f"{sid} - {name} ({region})": sid
            for sid, name, region in subs
        }
        self.substation_box = ttk.Combobox(
            frame, values=list(self.substation_map.keys()), width=55
        )
        self.substation_box.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(frame, text="Severity").grid(row=1, column=0, padx=5, pady=5)
        self.severity_box = ttk.Combobox(
            frame, values=["Low", "Medium", "High", "Critical"],
            state="readonly"
        )
        self.severity_box.current(1)
        self.severity_box.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(frame, text="Description").grid(row=2, column=0, padx=5, pady=5)
        self.description = ttk.Entry(frame, width=60)
        self.description.grid(row=2, column=1, padx=5, pady=5)

        ttk.Button(frame, text="Report Outage",
                   command=self.report_outage).grid(row=3, column=1, pady=10)

        ttk.Label(self.root, text="Current Outages",
                  font=("Arial", 14, "bold")).pack(pady=5)
        self.outage_table(self.root, database.get_outages())

    def report_outage(self):
        selected = self.substation_box.get()
        description = self.description.get().strip()
        severity = self.severity_box.get()

        if not selected or not description:
            messagebox.showwarning(
                "Missing Information",
                "Select a substation and enter a description."
            )
            return

        outage_id = database.add_outage(
            self.substation_map[selected],
            self.username_value,
            description,
            severity
        )
        messagebox.showinfo("Success",
                            f"Outage #{outage_id} has been reported.")
        self.show_dashboard("engineer")

    def admin_page(self):
        ttk.Label(self.root, text="All Outages",
                  font=("Arial", 14, "bold")).pack(pady=5)
        self.outage_table(self.root, database.get_outages())

        frame = ttk.LabelFrame(self.root, text="Create Work Order")
        frame.pack(fill="x", padx=20, pady=10)

        outages = database.get_open_outages()
        self.outage_map = {
            f"#{row[0]} - {row[1]} - {row[3]}": row[0]
            for row in outages
        }

        ttk.Label(frame, text="Outage").grid(row=0, column=0, padx=5, pady=5)
        self.admin_outage = ttk.Combobox(
            frame, values=list(self.outage_map.keys()), width=45
        )
        self.admin_outage.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(frame, text="Technician").grid(row=1, column=0, padx=5, pady=5)
        self.tech_box = ttk.Combobox(
            frame, values=database.get_technicians(), state="readonly"
        )
        self.tech_box.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(frame, text="Scheduled Date").grid(row=2, column=0, padx=5, pady=5)
        self.date_entry = ttk.Entry(frame, width=25)
        self.date_entry.insert(0, "YYYY-MM-DD")
        self.date_entry.grid(row=2, column=1, padx=5, pady=5)

        ttk.Button(frame, text="Create Work Order",
                   command=self.create_work_order).grid(row=3, column=1, pady=10)

    def create_work_order(self):
        outage = self.admin_outage.get()
        technician = self.tech_box.get()
        date = self.date_entry.get().strip()

        if not outage or not technician or not date:
            messagebox.showwarning("Missing Information",
                                   "Complete all fields.")
            return

        work_id = database.create_work_order(
            self.outage_map[outage], technician, date
        )
        messagebox.showinfo("Success",
                            f"Work Order #{work_id} created.")
        self.show_dashboard("admin")

    def technician_page(self):
        rows = database.get_my_work_orders(self.username_value)

        ttk.Label(self.root, text="My Assigned Work Orders",
                  font=("Arial", 14, "bold")).pack(pady=10)

        columns = ("WO ID", "Outage", "Substation", "Region",
                   "Description", "Date", "Status")
        tree = ttk.Treeview(self.root, columns=columns,
                            show="headings", height=15)
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=105)
        tree.column("Description", width=170)

        for row in rows:
            tree.insert("", "end", values=row)

        tree.pack(fill="both", expand=True, padx=15, pady=10)
        self.tech_tree = tree

        ttk.Button(
            self.root, text="Mark In Progress",
            command=lambda: self.change_work("In Progress")
        ).pack(side="left", padx=80, pady=10)

        ttk.Button(
            self.root, text="Mark Completed",
            command=lambda: self.change_work("Completed")
        ).pack(side="right", padx=80, pady=10)

    def change_work(self, status):
        selected = self.tech_tree.selection()
        if not selected:
            messagebox.showwarning("Select Work",
                                   "Select a work order first.")
            return

        work_id = self.tech_tree.item(selected[0], "values")[0]
        database.update_work_order(work_id, status)
        messagebox.showinfo("Updated",
                            f"Work order marked {status}.")
        self.show_dashboard("technician")

    def customer_page(self):
        frame = ttk.LabelFrame(self.root, text="Log Customer Complaint")
        frame.pack(fill="x", padx=30, pady=20)

        ttk.Label(frame, text="Customer Name/Reference").grid(
            row=0, column=0, padx=5, pady=8)
        self.customer_name = ttk.Entry(frame, width=45)
        self.customer_name.grid(row=0, column=1, padx=5, pady=8)

        ttk.Label(frame, text="Complaint").grid(
            row=1, column=0, padx=5, pady=8)
        self.complaint = ttk.Entry(frame, width=45)
        self.complaint.grid(row=1, column=1, padx=5, pady=8)

        ttk.Label(frame, text="Outage ID (optional)").grid(
            row=2, column=0, padx=5, pady=8)
        self.complaint_outage = ttk.Entry(frame, width=20)
        self.complaint_outage.grid(row=2, column=1, padx=5, pady=8)

        ttk.Button(frame, text="Save Complaint",
                   command=self.save_complaint).grid(row=3, column=1, pady=10)

        ttk.Label(self.root, text="Existing Outages",
                  font=("Arial", 14, "bold")).pack(pady=10)
        self.outage_table(self.root, database.get_outages())

    def save_complaint(self):
        customer = self.customer_name.get().strip()
        complaint = self.complaint.get().strip()
        outage = self.complaint_outage.get().strip()

        if not customer or not complaint:
            messagebox.showwarning(
                "Missing Information",
                "Enter customer details and complaint."
            )
            return

        database.add_complaint(
            customer, complaint, outage, self.username_value
        )
        messagebox.showinfo("Saved", "Customer complaint saved.")
        self.show_dashboard("customer_service")


root = tk.Tk()
app = GridCareLiteApp(root)
root.mainloop()
