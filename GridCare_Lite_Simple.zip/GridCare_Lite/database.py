import sqlite3
import hashlib
import csv
from datetime import datetime

DB_NAME = "gridcare.db"


def connect():
    return sqlite3.connect(DB_NAME)


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def setup_database():
    db = connect()
    cur = db.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS substations (
        substation_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        region TEXT NOT NULL
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS outages (
        outage_id INTEGER PRIMARY KEY AUTOINCREMENT,
        substation_id TEXT NOT NULL,
        reported_by TEXT NOT NULL,
        description TEXT NOT NULL,
        severity TEXT NOT NULL,
        status TEXT NOT NULL,
        reported_at TEXT NOT NULL,
        resolved_at TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS work_orders (
        work_order_id INTEGER PRIMARY KEY AUTOINCREMENT,
        outage_id INTEGER NOT NULL,
        assigned_technician TEXT NOT NULL,
        scheduled_date TEXT NOT NULL,
        status TEXT NOT NULL
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS complaints (
        complaint_id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_reference TEXT NOT NULL,
        description TEXT NOT NULL,
        outage_id INTEGER,
        logged_by TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")

    users = [
        ("admin", "1234", "admin"),
        ("engineer", "5678", "engineer"),
        ("technician", "1711", "technician"),
        ("customer_service", "1911", "customer_service")
    ]

    for username, password, role in users:
        cur.execute(
            "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            (username, hash_password(password), role)
        )

    try:
        with open("substations.csv", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                sid = row.get("Substation ID", "").strip()
                name = row.get("Name", "").strip()
                region = row.get("Region", "").strip()
                if sid and name and region:
                    cur.execute(
                        "INSERT OR REPLACE INTO substations VALUES (?, ?, ?)",
                        (sid, name, region)
                    )
    except FileNotFoundError:
        pass

    db.commit()
    db.close()


def check_login(username, password):
    db = connect()
    row = db.execute(
        "SELECT role FROM users WHERE username=? AND password_hash=?",
        (username, hash_password(password))
    ).fetchone()
    db.close()
    return row[0] if row else None


def get_substations():
    db = connect()
    rows = db.execute(
        "SELECT substation_id, name, region FROM substations ORDER BY name"
    ).fetchall()
    db.close()
    return rows


def add_outage(substation_id, username, description, severity):
    db = connect()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur = db.cursor()
    cur.execute(
        """INSERT INTO outages
        (substation_id, reported_by, description, severity, status, reported_at)
        VALUES (?, ?, ?, ?, 'Open', ?)""",
        (substation_id, username, description, severity, now)
    )
    outage_id = cur.lastrowid
    db.commit()
    db.close()
    return outage_id


def get_outages():
    db = connect()
    rows = db.execute(
        """SELECT o.outage_id, s.name, s.region, o.description,
                  o.severity, o.status, o.reported_at
           FROM outages o JOIN substations s
           ON o.substation_id=s.substation_id
           ORDER BY o.outage_id DESC"""
    ).fetchall()
    db.close()
    return rows


def get_open_outages():
    db = connect()
    rows = db.execute(
        """SELECT o.outage_id, s.name, s.region, o.description, o.status
           FROM outages o JOIN substations s
           ON o.substation_id=s.substation_id
           WHERE o.status != 'Resolved'
           ORDER BY o.outage_id DESC"""
    ).fetchall()
    db.close()
    return rows


def get_technicians():
    db = connect()
    rows = db.execute(
        "SELECT username FROM users WHERE role='technician' ORDER BY username"
    ).fetchall()
    db.close()
    return [r[0] for r in rows]


def create_work_order(outage_id, technician, scheduled_date):
    db = connect()
    cur = db.cursor()
    cur.execute(
        """INSERT INTO work_orders
           (outage_id, assigned_technician, scheduled_date, status)
           VALUES (?, ?, ?, 'Scheduled')""",
        (outage_id, technician, scheduled_date)
    )
    cur.execute(
        "UPDATE outages SET status='In Progress' WHERE outage_id=?",
        (outage_id,)
    )
    work_id = cur.lastrowid
    db.commit()
    db.close()
    return work_id


def get_my_work_orders(technician):
    db = connect()
    rows = db.execute(
        """SELECT w.work_order_id, w.outage_id, s.name, s.region,
                  o.description, w.scheduled_date, w.status
           FROM work_orders w
           JOIN outages o ON w.outage_id=o.outage_id
           JOIN substations s ON o.substation_id=s.substation_id
           WHERE w.assigned_technician=?
           ORDER BY w.work_order_id DESC""",
        (technician,)
    ).fetchall()
    db.close()
    return rows


def update_work_order(work_order_id, new_status):
    db = connect()
    db.execute(
        "UPDATE work_orders SET status=? WHERE work_order_id=?",
        (new_status, work_order_id)
    )
    if new_status == "Completed":
        db.execute(
            """UPDATE outages SET status='Resolved',
               resolved_at=? WHERE outage_id=(
                   SELECT outage_id FROM work_orders WHERE work_order_id=?
               )""",
            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), work_order_id)
        )
    db.commit()
    db.close()


def add_complaint(customer_reference, description, outage_id, logged_by):
    db = connect()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        """INSERT INTO complaints
           (customer_reference, description, outage_id, logged_by, created_at)
           VALUES (?, ?, ?, ?, ?)""",
        (customer_reference, description, outage_id or None, logged_by, now)
    )
    db.commit()
    db.close()


def report_counts():
    db = connect()
    result = (
        db.execute("SELECT COUNT(*) FROM outages WHERE status='Open'").fetchone()[0],
        db.execute("SELECT COUNT(*) FROM outages WHERE status='Resolved'").fetchone()[0],
        db.execute("SELECT COUNT(*) FROM work_orders").fetchone()[0]
    )
    db.close()
    return result
