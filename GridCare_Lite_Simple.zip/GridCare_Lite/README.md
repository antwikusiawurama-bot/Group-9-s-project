GRIDCARE-LITE SIMPLE VERSION

Run:
    python gridcare.py

Demo accounts:
admin / 1234
engineer / 5678
technician / 1711
customer_service / 1911

The program creates gridcare.db automatically and imports
substations.csv into the database.
