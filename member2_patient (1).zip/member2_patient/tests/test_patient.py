import io
import json
import os
import tempfile
import unittest

import app_patient
from file_handler import allowed_file, save_submission_file
from completeness_checker import check_csv_completeness
from patient_data import save_submission, get_patient_submission


class PatientTests(unittest.TestCase):

    def test_allowed_extensions(self):
        self.assertTrue(allowed_file("a.txt"))
        self.assertTrue(allowed_file("a.csv"))
        self.assertTrue(allowed_file("a.pdf"))
        self.assertFalse(allowed_file("a.jpg"))
        self.assertFalse(allowed_file("a.png"))
        self.assertFalse(allowed_file("a.docx"))

    def test_missing_file(self):
        with self.assertRaises(ValueError):
            save_submission_file(None, "12342024", "task001", "clinic001")

    def test_file_rename_and_folder(self):
        with tempfile.TemporaryDirectory() as temp:
            old = os.getcwd()
            os.chdir(temp)
            try:
                fake_file = io.BytesIO(b"hello")
                fake_file.filename = "myfile.txt"

                path = save_submission_file(
                    fake_file, "12342024", "task001", "clinic001"
                )

                self.assertTrue(
                    path.endswith("submissions/clinic001/12342024/12342024_task001.txt")
                )
                self.assertTrue(os.path.exists(path))
            finally:
                os.chdir(old)

    def test_csv_missing_column(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".csv", delete=False, encoding="utf-8"
        ) as file:
            file.write("date,wrong\n2026-08-28,10\n")
            path = file.name

        try:
            ok, errors = check_csv_completeness(path)
            self.assertFalse(ok)
            self.assertTrue(any("Missing required columns" in e for e in errors))
        finally:
            os.remove(path)

    def test_csv_empty_field(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".csv", delete=False, encoding="utf-8"
        ) as file:
            file.write("date,reading\n2026-08-28,\n")
            path = file.name

        try:
            ok, errors = check_csv_completeness(path)
            self.assertFalse(ok)
            self.assertTrue(any("reading cannot be empty" in e for e in errors))
        finally:
            os.remove(path)

    def test_submission_metadata(self):
        with tempfile.TemporaryDirectory() as temp:
            old = os.getcwd()
            os.chdir(temp)
            try:
                os.makedirs("data", exist_ok=True)
                with open("data/task_submissions.json", "w") as f:
                    json.dump({}, f)

                submission = save_submission(
                    "12342024", "task001", "clinic001",
                    "submissions/clinic001/12342024/12342024_task001.txt",
                    on_time=True, points_awarded=True
                )

                self.assertEqual(submission["review_status"], "Pending")
                self.assertTrue(submission["timestamp"])
                self.assertTrue(submission["on_time"])
                self.assertTrue(os.path.exists("data/task_submissions.json"))

                found = get_patient_submission("12342024", "task001")
                self.assertEqual(found["patient_id"], "12342024")
            finally:
                os.chdir(old)

    def test_unauthorised_task(self):
        client = app_patient.app.test_client()
        response = client.post("/patient/upload/not_assigned")
        self.assertEqual(response.status_code, 302)


if __name__ == "__main__":
    unittest.main()
