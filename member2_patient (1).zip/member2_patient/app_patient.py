from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime, date
import os

from file_handler import save_submission_file
from patient_data import (
    load_json, save_submission, update_theme, get_patient_tasks,
    get_patient_submission, add_engagement_points
)
from completeness_checker import check_csv_completeness

app = Flask(__name__)
app.secret_key = "cliniccare-lite-test-key"

DATA_DIR = "data"
TASKS_FILE = os.path.join(DATA_DIR, "health_tasks.json")
USERS_FILE = os.path.join(DATA_DIR, "users.json")

# Temporary login for testing.
# During final integration, Member 1 should set session["user_id"].
TEST_PATIENT_ID = "12342024"


def get_logged_in_patient():
    patient_id = session.get("user_id", TEST_PATIENT_ID)
    users = load_json(USERS_FILE)
    return patient_id, users.get(patient_id)


@app.route("/")
def home():
    return redirect(url_for("patient_dashboard"))


@app.route("/patient/dashboard")
def patient_dashboard():
    patient_id, user = get_logged_in_patient()

    if not user or user.get("role") != "patient":
        return "Patient not found.", 404

    tasks = get_patient_tasks(patient_id, user.get("clinic_id", ""))

    for task in tasks:
        submission = get_patient_submission(patient_id, task["task_id"])
        if submission:
            task["submission_status"] = "Submitted"
            task["review_status"] = submission.get("review_status", "Pending")
            task["notes"] = submission.get("notes", "")
        else:
            task["submission_status"] = "Not Submitted"
            task["review_status"] = "Not Reviewed"
            task["notes"] = ""

    tasks_completed_on_time = sum(
        1 for task in tasks
        if get_patient_submission(patient_id, task["task_id"])
        and get_patient_submission(patient_id, task["task_id"]).get("on_time")
    )

    return render_template(
        "patient_dashboard.html",
        user=user,
        tasks=tasks,
        tasks_completed_on_time=tasks_completed_on_time
    )


@app.route("/patient/upload/<task_id>", methods=["POST"])
def patient_upload(task_id):
    patient_id, user = get_logged_in_patient()

    if not user or user.get("role") != "patient":
        return "Patient not found.", 404

    tasks = load_json(TASKS_FILE)
    task = tasks.get(task_id)

    if not task:
        flash("Task does not exist.", "error")
        return redirect(url_for("patient_dashboard"))

    if patient_id not in task.get("assigned_patient_ids", []):
        flash("You are not authorised to submit this task.", "error")
        return redirect(url_for("patient_dashboard"))

    file = request.files.get("submission_file")

    try:
        file_path = save_submission_file(
            file, patient_id, task_id, user.get("clinic_id", "")
        )

        # CSV structural check only. No medical interpretation.
        if file_path.lower().endswith(".csv"):
            complete, errors = check_csv_completeness(file_path)
            if not complete:
                os.remove(file_path)
                flash("CSV check failed: " + " ".join(errors), "error")
                return redirect(url_for("patient_dashboard"))

        # Points are awarded only the first time this task is submitted.
        old_submission = get_patient_submission(patient_id, task_id)
        due_date = date.fromisoformat(task["due_date"])
        submitted_date = datetime.now().date()
        on_time = submitted_date <= due_date

        submission = save_submission(
            patient_id, task_id, user.get("clinic_id", ""), file_path,
            on_time=on_time, points_awarded=(old_submission is None and on_time)
        )

        if old_submission is None and on_time:
            add_engagement_points(patient_id, 10)

        flash("File submitted successfully.", "success")

    except ValueError as error:
        flash(str(error), "error")

    return redirect(url_for("patient_dashboard"))


@app.route("/patient/theme", methods=["POST"])
def patient_theme():
    patient_id, user = get_logged_in_patient()

    if not user:
        return "Patient not found.", 404

    theme = request.form.get("theme", "colorful")

    if theme not in ["colorful", "dark"]:
        theme = "colorful"

    update_theme(patient_id, theme)
    flash("Theme updated.", "success")
    return redirect(url_for("patient_dashboard"))


if __name__ == "__main__":
    app.run(debug=True)
