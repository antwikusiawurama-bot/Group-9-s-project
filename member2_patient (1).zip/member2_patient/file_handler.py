import os
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {"txt", "csv", "pdf"}


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


def save_submission_file(file, patient_id, task_id, clinic_id):
    if not file or file.filename == "":
        raise ValueError("No file selected.")

    if not allowed_file(file.filename):
        raise ValueError("Only .txt, .csv, and .pdf files are allowed.")

    extension = file.filename.rsplit(".", 1)[1].lower()

    safe_patient_id = secure_filename(str(patient_id))
    safe_task_id = secure_filename(str(task_id))
    safe_clinic_id = secure_filename(str(clinic_id))

    filename = f"{safe_patient_id}_{safe_task_id}.{extension}"

    upload_folder = os.path.join(
        "submissions", safe_clinic_id, safe_patient_id
    )

    os.makedirs(upload_folder, exist_ok=True)

    file_path = os.path.join(upload_folder, filename)
    file.save(file_path)

    return file_path
