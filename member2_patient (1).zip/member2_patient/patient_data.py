import json
import os
from datetime import datetime

DATA_DIR = "data"
SUBMISSIONS_FILE = os.path.join(DATA_DIR, "task_submissions.json")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
TASKS_FILE = os.path.join(DATA_DIR, "health_tasks.json")


def load_json(file_path):
    if not os.path.exists(file_path):
        return {}

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, OSError):
        return {}


def save_json(file_path, data):
    os.makedirs(os.path.dirname(file_path) or ".", exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4)


def save_submission(
    patient_id, task_id, clinic_id, file_path,
    on_time=False, points_awarded=False
):
    submissions = load_json(SUBMISSIONS_FILE)
    submission_id = f"{patient_id}_{task_id}"

    # Resubmission replaces the file and keeps the same submission record.
    submissions[submission_id] = {
        "patient_id": patient_id,
        "task_id": task_id,
        "clinic_id": clinic_id,
        "file_path": file_path,
        "timestamp": datetime.now().isoformat(),
        "review_status": "Pending",
        "notes": "",
        "reviewer_id": None,
        "review_timestamp": None,
        "on_time": on_time,
        "points_awarded": points_awarded
    }

    save_json(SUBMISSIONS_FILE, submissions)
    return submissions[submission_id]


def get_patient_submission(patient_id, task_id):
    submissions = load_json(SUBMISSIONS_FILE)
    submission = submissions.get(f"{patient_id}_{task_id}")

    if submission and submission.get("patient_id") == patient_id:
        return submission

    return None


def get_patient_tasks(patient_id, clinic_id):
    tasks = load_json(TASKS_FILE)
    patient_tasks = []

    for task in tasks.values():
        if (
            task.get("clinic_id") == clinic_id
            and patient_id in task.get("assigned_patient_ids", [])
        ):
            patient_tasks.append(dict(task))

    return patient_tasks


def update_theme(patient_id, theme):
    users = load_json(USERS_FILE)

    if patient_id in users:
        users[patient_id]["theme"] = theme
        save_json(USERS_FILE, users)


def add_engagement_points(patient_id, points):
    users = load_json(USERS_FILE)

    if patient_id in users:
        current = users[patient_id].get("engagement_points", 0)
        users[patient_id]["engagement_points"] = current + points
        save_json(USERS_FILE, users)
