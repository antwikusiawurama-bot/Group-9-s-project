CLINICCARE-LITE - MEMBER 2 PATIENT SUBSYSTEM

1. Install Python 3.
2. Open Command Prompt in this folder.
3. Install Flask:
   pip install flask

4. Start the app:
   python app_patient.py

5. Open:
   http://127.0.0.1:5000/patient/dashboard

TEST PATIENT:
ID: 12342024
Name: Ama Patient

TESTS:
python -m unittest discover -s tests

IMPORTANT:
This is the independent Member 2 version.
During final integration, replace the temporary TEST_PATIENT_ID with:
session["user_id"]
from the main authentication system.

The app accepts only .txt, .csv and .pdf.
CSV files are checked only for required structure:
date and reading columns, and non-empty required fields.
No medical interpretation is performed.
