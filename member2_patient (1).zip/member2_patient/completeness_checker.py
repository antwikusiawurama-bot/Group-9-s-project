import csv


def check_csv_completeness(file_path, required_columns=None):
    if required_columns is None:
        required_columns = ["date", "reading"]

    errors = []

    try:
        with open(file_path, "r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)

            if reader.fieldnames is None:
                return False, ["The CSV file has no column headers."]

            missing_columns = [
                column for column in required_columns
                if column not in reader.fieldnames
            ]

            if missing_columns:
                errors.append(
                    "Missing required columns: " + ", ".join(missing_columns)
                )

            for row_number, row in enumerate(reader, start=2):
                for column in required_columns:
                    if column in row and not row[column].strip():
                        errors.append(
                            f"Row {row_number}: {column} cannot be empty."
                        )

    except Exception as error:
        return False, [f"Could not read CSV file: {error}"]

    return len(errors) == 0, errors
